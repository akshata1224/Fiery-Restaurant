import { Component } from '@angular/core';

@Component({
  selector: 'app-place-order',
  standalone: true,
  imports: [],
  templateUrl: './place-order.component.html',
  styleUrl: './place-order.component.css'
})
export class PlaceOrderComponent {

}
