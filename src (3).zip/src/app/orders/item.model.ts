export interface Item {
    itemNo: string;
    name: string;
    quantity: number;
    price: number;
    itemValue: number;
}
